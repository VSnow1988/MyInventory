/**
 * This class handles communication with the SQLite database for the My Inventory app.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */

package com.vsnow.myinventory.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseManager extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseManager"; // Name of the class used for logging
    private static DatabaseManager instance;
    private static final String DATABASE_NAME = "data.db";
    private static final int VERSION = 3;

    // Singleton pattern context getter ensures that multiple DatabaseManager instances are not created.
    public static DatabaseManager getInstance(Context context){
        if (instance == null){
            instance = new DatabaseManager(context);
            Log.v(TAG, "No instance of DatabaseManager exists. Creating...");
        }
        else {
            Log.v(TAG, "An instance of DatabaseManager exists. Fetching...");
        }
        return instance;
    }

    // Constructor using current application SQLite context.
    private DatabaseManager(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        try {
            db.execSQL("CREATE TABLE " + ItemTable.TABLE + " (" +
                    ItemTable.COL_ITEMNAME + " text primary key, " +
                    ItemTable.COL_NUMINSTOCK + " integer)");
        }
        catch (Exception exception) {
            Log.e(TAG, "Something went wrong while creating the database tables.", exception);
        }
    }

    // Mandatory to include in this class; Logic for what to do on upgrade, if anything.
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.v(TAG, "SQLiteDatabase has been upgraded.");
    }

    /**
     * Method to determine Alphanumeric String. Efficient method for Java 8+. Java regex classes have some bugs in current versions of Android/Kotlin/Compose.
     * @param str A String to check for alphanumeric-only character values.
     * @return A boolean that indicates whether or not the string is alphanumeric.
     */
    boolean isAlphaNumeric(String str) {
        return str != null && str.chars().allMatch(Character::isLetterOrDigit);
    }

    /**
     * CRUD Method to read an Item from the database.
     * Uses a unique key to find an Item making its time complexity optimal O(1).
     * @param itemName The name field for the ITEMNAME to look up. Unique primary key.
     * @return A boolean indicating whether or not the item name was found.
     */
    public boolean itemExists(String itemName){

        boolean exists = false; // Initialize the return variable to a default.

        try { // Attempt to search the database for the given Item in the database.
            SQLiteDatabase db = getReadableDatabase();
            String sql = "select * from " + ItemTable.TABLE +
                    " WHERE " + ItemTable.COL_ITEMNAME + " = ? ";
            Cursor cursor = db.rawQuery(sql, new String[]{itemName});

            if (cursor.moveToFirst()) { // If a matching ITEMNAME primary key is found
                exists = true;
            } else { // Else ensure the function returns false
                exists = false;
            }

            cursor.close();
        }
        catch (Exception exception){
            Log.e(TAG, "An error occurred in itemExists while trying to find an item in the database.", exception);
        }
        return exists;
    }

    /**
     * CRUD Method to Create an Item in the database. Returns a long ID for the created entry, 0 if failed.
     * Time complexity is O(1) to find an item by a unique key.
     *
     * @param name  The name field for the Item to look up. Unique primary key.
     * @param count The number in stock (NUMINSTOCK) field for the item.
     */
    public void addItem(String name, int count) {


        try {
            if ( name == null ) { // Check if the name is null first before other comparisons. Integers can't be null so no need to check here.
                throw new IllegalArgumentException("Name was found to be null.");
            }
            else if (count < 0 || count > 999999) { // If the count is not within the limits of the application set to avoid database overflow and disruption of service.
                throw new Exception("The count was under 0 or longer than 6 digits.");
            }
            else if (!isAlphaNumeric(name)) { // Check if the string is not alphanumeric, which prevents code injections.
                throw new IllegalArgumentException("Item name was not alphanumeric.");
            }
            else { // Validated, attempt to add to the database.
                SQLiteDatabase db = getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(ItemTable.COL_ITEMNAME, name);
                values.put(ItemTable.COL_NUMINSTOCK, count);
                db.insert(ItemTable.TABLE, null, values);
            }
        }
        catch (Exception exception){
            Log.e(TAG, "An error occurred in addItem while trying to create a new entry in the database.", exception);
        }
    }

    /**
     * Method to read from the database and return all items as an iterable object.
     * Time complexity is O(n) for every item in the database.
     * @return an iterable Cursor of the ItemTable.
     */
    public Cursor readItems(){

        SQLiteDatabase db = getWritableDatabase();
        String sql = "select * from " + ItemTable.TABLE;

        return db.rawQuery(sql, new String[]{});

    }

    /**
     * Method to update an item's count in the database.
     *
     * @param name      the item's unique name.
     * @param count     the item' current count.
     * @param direction 0 for increasing, 1 for decreasing.
     */
    public void updateItem(String name, String count, int direction) {
        SQLiteDatabase db = getWritableDatabase();
        int countInt = Integer.parseInt(count);

        try {
            if (direction == 0) { // If Up was clicked
                countInt += 1;
                if (countInt > 999999) { // Do not increase the count to a number greater than 6 digits. This prevents overflow and DoS.
                    throw new Exception("Item count cannot be greater than six digits.");
                }
                else {
                    Log.v(TAG, "Increased an item's count by 1.");
                }
            } else if (direction == 1) { // If Down was clicked
                countInt -= 1;
                if (countInt <= 0) { // Do not decrease count to less than 0. This prevents underflow and nonsensical operations.
                    throw new Exception("Item count cannot be less than zero.");
                } else {
                    Log.v(TAG, "Decreased an item's count by 1.");
                }
            } else { // If the provided direction argument was neither 0 nor 1 (increase or decrease)
                throw new IllegalArgumentException("Updating item count failed. Invalid argument for direction parameter.");
            }
            // If direction was provided, attempt to update the item.
            ContentValues values = new ContentValues();
            values.put(ItemTable.COL_NUMINSTOCK, Integer.toString(countInt));
            db.update(ItemTable.TABLE, values, "item_name = ?",
                    new String[] { name });
        }
        catch (Exception exception) {
            Log.e(TAG, "Something went wrong while updating the item count.", exception);
        }
    }

     /**
      * Method to delete an inventory item from the database.
      * Time complexity is O(1) to find an item by a unique key.
      *
      * @param name the unique name of an item.
      */
    public void deleteItem(String name) {

        try { // Attempt to find the item in the database and delete it.
            SQLiteDatabase db = getWritableDatabase();
            db.delete(ItemTable.TABLE, ItemTable.COL_ITEMNAME + " = ?",
                    new String[]{name});
        }
        catch (Exception exception){ // If errors occur during the process
            Log.e(TAG, "Something went wrong while trying to delete an item.", exception);
        }
    }

    // Database Table structures
    private static final class ItemTable{

        private static final String TABLE = "items";
        private static final String COL_ITEMNAME = "item_name";
        private static final String COL_NUMINSTOCK = "stock";

    }

}
