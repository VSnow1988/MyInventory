package com.vsnow.myinventory.main;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.vsnow.myinventory.R;

/**
 * This class holds the view that is repeated and used to display data in the inventory list, laid out in the inventory_layout.xml.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */
public class inventoryViewHolder extends RecyclerView.ViewHolder {

    private static final String TAG = "inventoryViewHolder"; // Name of the class used for logging
    TextView textItemName;
    TextView textItemCount;
    ImageButton buttonItemIncrease;
    ImageButton buttonItemDecrease;
    ImageButton buttonItemDelete;
    View view;

    // Initializer with all the UI elements of the inventory_item layout
    inventoryViewHolder(View itemView) {
        super(itemView);
        textItemName = (TextView)itemView.findViewById(R.id.textItemName);
        textItemCount = (TextView)itemView.findViewById(R.id.textItemCount);
        buttonItemIncrease = (ImageButton)itemView.findViewById(R.id.buttonItemIncrease);
        buttonItemDecrease = (ImageButton)itemView.findViewById(R.id.buttonItemDecrease);
        buttonItemDelete = (ImageButton)itemView.findViewById(R.id.buttonItemDelete);
        view = itemView;
    }
    // FIXME: Change the icons in the rows to something more clear (+ and - perhaps) in inventory_item.xml and put spacing for small numbers
}

