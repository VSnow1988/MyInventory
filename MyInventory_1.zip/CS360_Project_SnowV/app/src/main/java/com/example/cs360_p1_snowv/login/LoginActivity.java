package com.example.cs360_p1_snowv.login;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360_p1_snowv.R;
import com.example.cs360_p1_snowv.main.MainActivity;
import com.example.cs360_p1_snowv.data.DatabaseManager;


// Main class for the 'Log In' screen.
public class LoginActivity extends AppCompatActivity {

    // Private class variables for the changeable UI elements.
    private EditText txtUsername;
    private EditText txtPassword;
    private TextView msgText;

    // Set variables and click listeners when this screen (activity) is created.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Use this layout.

        // Variables for UI elements
        txtUsername = findViewById(R.id.entryUsername);
        txtPassword = findViewById(R.id.entryPassword);
        msgText = findViewById(R.id.messageLogin);
        Button btnLogin = (Button)findViewById(R.id.buttonLogIn);
        Button btnNewUser = (Button)findViewById(R.id.buttonNewUser);

        // Actions for button clicks
        btnLogin.setOnClickListener(l -> handleLogin());
        btnNewUser.setOnClickListener(l -> handleNewUser());
        // FIXME: Tapping the 'eye' button should show/hide the password text.
    }

    // Clear the text fields when resuming this activity for security purposes.
    @Override
    public void onResume() {
        super.onResume();
        txtPassword.setText("");
        txtUsername.setText("");
        msgText.setText("");
    }

    // Method for validating strings as alphanumeric and not null.
    private boolean isAlphaNumeric(String str) {
        if ( str != null && str.chars().allMatch(Character::isLetterOrDigit) ) {
            return true;
        }
        else {
            return false;
        }
    }

    // Called when 'Login' button is clicked; Validates credentials and runs the main activity.
    private void handleLogin() {
        // Error handling with logging feature.
        try {
            // Convert the fields' current text to a String and get error messages from the xml.
            String username = txtUsername.getText().toString();
            String password = txtPassword.getText().toString();
            String loginError = getResources().getString(R.string.message_login_error);
            String loginWrong = getResources().getString(R.string.message_login_wrong);

            // Validate the input before interacting with the database.
            if (username.length() > 10 || password.length() > 25) { // Check username & password length to prevent memory overuse or overflow.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password entered was longer than the maximum length.");
            }
            else if ( !isAlphaNumeric(username) || !isAlphaNumeric(password)) { // Check that something was entered in the fields and is alphanumeric.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password must contain only alphanumeric characters and not be empty.");
            }
            else {
                // If username and password match is found in database, log in the user and go to main activity. If not, display error message.
                if (DatabaseManager.getInstance(getApplicationContext()).authenticate(username, password)) {
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                } else {
                    msgText.setText(loginWrong); // Show message to the user.
                    throw new SecurityException("Invalid credentials were entered.");
                }
            }
        }
        catch (Exception exception){ // Code to run in case of any exception.
            // Placeholder for future remote error logging. This is just for development.
            System.out.println(exception);
        }
    }

    // Called when 'New User' button is clicked; Adds a new user with input as credentials given.
    private void handleNewUser() {
        try {
            // Convert the fields' current text to a String.
            String username = txtUsername.getText().toString();
            String password = txtPassword.getText().toString();
            String loginError = getResources().getString(R.string.message_login_error);
            String userExists = getResources().getString(R.string.message_newuser_exists);
            String userAdded = getResources().getString(R.string.message_newuser_added);

            // Validate the input before interacting with the database.
            if (username.length() < 4 || username.length() > 10 || password.length() < 8 || password.length() > 25) { // Credential requirements for security and to prevent overflow.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password entered was longer or shorter than allowed length.");
            }
            else if ( !isAlphaNumeric(username) || !isAlphaNumeric(password)) { // Check that something was entered in the fields and is alphanumeric.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password must contain only alphanumeric characters and not be empty.");
            }
            else {
                // If the username already exists, display an error message.
                if (DatabaseManager.getInstance(getApplicationContext()).userExists(username)) {
                    msgText.setText(userExists); // Show message to the user.
                } else { // If not found in the database, add the user.
                    DatabaseManager.getInstance(getApplicationContext()).addUser(username, password); // Add to the database.
                    msgText.setText(userAdded); // Show message to the user.
                }
            }
        }
        catch (Exception exception) {
            // Placeholder for future remote error logging.
            System.out.println(exception);
        }
    }
}
