package com.example.cs360_p1_snowv.main;

public class itemData {
    String name;
    String count;

    itemData(String name, String count){
        this.name = name;
        this.count = count;
    }
}
