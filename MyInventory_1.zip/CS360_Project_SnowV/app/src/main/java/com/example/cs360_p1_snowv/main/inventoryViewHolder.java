package com.example.cs360_p1_snowv.main;

import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs360_p1_snowv.R;

// This class holds the views that will be reused by the Recycler to display data (inventory_item.xml)
public class inventoryViewHolder extends RecyclerView.ViewHolder {
    TextView textItemName;
    TextView textItemCount;
    ImageButton buttonItemIncrease;
    ImageButton buttonItemDecrease;
    ImageButton buttonItemDelete;
    View view;

    // Initializer with all the UI elements of the inventory_item layout
    inventoryViewHolder(View itemView) {
        super(itemView);
        textItemName = (TextView)itemView.findViewById(R.id.textItemName);
        textItemCount = (TextView)itemView.findViewById(R.id.textItemName);
        buttonItemIncrease = (ImageButton)itemView.findViewById(R.id.buttonItemIncrease);
        buttonItemDecrease = (ImageButton)itemView.findViewById(R.id.buttonItemDecrease);
        buttonItemDelete = (ImageButton)itemView.findViewById(R.id.buttonItemDelete);
        view = itemView;
    }
}

