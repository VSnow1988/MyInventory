package com.example.cs360_p1_snowv.main;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;
import com.example.cs360_p1_snowv.R;

import java.util.Collections;
import java.util.List;

// This class populates a Recycler View with other views (the recycler_row layout) using a list of data.
public class inventoryAdapter extends RecyclerView.Adapter<inventoryViewHolder> {

    List<itemData> localDataSet = Collections.emptyList(); // Local copy of the data to pass in
    Context context;

    // Initializer for the Adapter with the list of itemData created in the Main Activity
    public inventoryAdapter(List<itemData> list, Context context) {
        localDataSet = list;
    }

    // The ViewHolder holds the views that we wish to 'recycle' with different data in them (in this case, our list rows)
    // Create new views (invoked by the layout manager)
    @Override
    public inventoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext(); // Use the application context
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the layout using the inventory_item.xml
        View inventoryView = inflater.inflate(R.layout.inventory_item, parent, false);

        return new inventoryViewHolder(inventoryView);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(final inventoryViewHolder viewHolder, final int position) {
        // Get element from your dataset at this position and replace the contents of the view with that element
        viewHolder.textItemName.setText(localDataSet.get(position).name);
        viewHolder.textItemCount.setText(localDataSet.get(position).count);
        // FIXME: Tapping the count should open a pop-up to allow editing the number, in case the user wants to recount or decrease/increase by more than one.
        // FIXME: Each button should perform the appropriate action and then update the database entry for that item.
        viewHolder.buttonItemDecrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

            }
        });
        viewHolder.buttonItemIncrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

            }
        });
        viewHolder.buttonItemDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

            }
        });
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return localDataSet.size();
    }
}

