package com.example.cs360_p1_snowv.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// This class handles communication with the database in the application.
public class DatabaseManager extends SQLiteOpenHelper {

    private static DatabaseManager instance;
    private static final String DATABASE_NAME = "data.db";
    private static final int VERSION = 3;

    // Constructors. Singleton pattern ensures only one instance runs at a time.
    public static DatabaseManager getInstance(Context context){
        if (instance == null){
            instance = new DatabaseManager(context);
        }
        return instance;
    }

    private DatabaseManager(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE " + UserTable.TABLE + " (" +
                UserTable.COL_USERNAME + " text primary key, " +
                UserTable.COL_PASSWORD + " text)");

        db.execSQL("CREATE TABLE " + ItemTable.TABLE + " (" +
                ItemTable.COL_ITEMNAME + " text primary key, " +
                ItemTable.COL_NUMINSTOCK + " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV){
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    // Method to check login credentials
    public boolean authenticate(String username, String password){
        boolean isAuthenticated = false;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE +
                " WHERE " + UserTable.COL_USERNAME + " = ? AND " +
                UserTable.COL_PASSWORD + " = ? ";
        Cursor cursor = db.rawQuery(sql, new String[]{username, password});

        if (cursor.moveToFirst()){
            isAuthenticated = true;
        }

        return isAuthenticated;
    }

    // Finds out if a username already exists
    public boolean userExists(String username){
        boolean exists = false;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE +
                " WHERE " + UserTable.COL_USERNAME + " = ? ";
        Cursor cursor = db.rawQuery(sql, new String[]{username});

        if (cursor.moveToFirst()){
            exists = true;
        }

        return exists;
    }

    // Method to add a new user
    public long addUser(String name, String pass) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, name);
        values.put(UserTable.COL_PASSWORD, pass);

        long userId = db.insert(UserTable.TABLE, null, values);
        return userId;
    }

    // Finds out if an item already exists
    public boolean itemExists(String itemName){
        boolean exists = false;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + ItemTable.TABLE +
                " WHERE " + ItemTable.COL_ITEMNAME + " = ? ";
        Cursor cursor = db.rawQuery(sql, new String[]{itemName});

        if (cursor.moveToFirst()){
            exists = true;
        }

        return exists;
    }

    // Method to add a new item
    public long addItem(String name, int count) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_ITEMNAME, name);
        values.put(ItemTable.COL_NUMINSTOCK, count);

        long itemId = db.insert(ItemTable.TABLE, null, values);
        return itemId;
    }

    // Read all items from database and return as an iterable Cursor.
    public Cursor readItems(){
        SQLiteDatabase db = getWritableDatabase();

        String sql = "select * from " + ItemTable.TABLE;
        Cursor cursor = db.rawQuery(sql, new String[]{});

        return cursor;
    }

    // Change an item's count. Called when arrow buttons are clicked.
    // Use 0 for up, 1 for down as the 'dir' parameter.
    public boolean updateItem(String name, String count, int dir) {
        SQLiteDatabase db = getWritableDatabase();
        int countInt = Integer.parseInt(count);

        if (countInt <= 0) {
            return false;
        }
        if (dir == 0) { // Up clicked
            countInt += 1;
        }
        else if (dir == 1) { // Down clicked
            countInt -= 1;
        }

        ContentValues values = new ContentValues();
            values.put(ItemTable.COL_NUMINSTOCK, Integer.toString(countInt));
        int rowsUpdated = db.update(ItemTable.TABLE, values, "item_name = ?",
                new String[] { name });
        return rowsUpdated > 0;
    }

    // Deletes an item with supplied unique item name.
    public boolean deleteItem(String name) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(ItemTable.TABLE, ItemTable.COL_ITEMNAME + " = ?",
                new String[] {name});
        return rowsDeleted > 0;
    }

    // Database Table structures
    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";

    }

    private static final class ItemTable{

        private static final String TABLE = "items";
        private static final String COL_ITEMNAME = "item_name";
        private static final String COL_NUMINSTOCK = "stock";

    }

}
