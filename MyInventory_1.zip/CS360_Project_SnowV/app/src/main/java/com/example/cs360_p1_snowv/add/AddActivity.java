package com.example.cs360_p1_snowv.add;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.cs360_p1_snowv.R;
import com.example.cs360_p1_snowv.data.DatabaseManager;
import com.example.cs360_p1_snowv.main.MainActivity;

import java.util.InputMismatchException;

// Main class for the 'Add Item' screen.
public class AddActivity extends AppCompatActivity {
    // Private variable declarations for changeable UI elements.
    private TextView msgText;
    private EditText itemName;
    private EditText itemCount;

    // Assigns variables for UI elements and click listeners for buttons when this view is created.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add); // Use this layout.

        // Variables for UI elements
        Button btnAddConfirm = findViewById(R.id.buttonConfirm);
        Button btnReturnHome = findViewById(R.id.buttonReturn);
        msgText = findViewById(R.id.messageAdd);
        itemName = findViewById(R.id.entryItemName);
        itemCount = findViewById(R.id.entryItemCount);

        // Actions for button clicks
        btnAddConfirm.setOnClickListener(l -> handleAddConfirm(itemName, itemCount));
        btnReturnHome.setOnClickListener(l -> handleReturnHome());
    }

    // Method to go back to the Main activity
    private void handleReturnHome() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    // Add the item to the database and display confirmation message.
    private void handleAddConfirm(EditText item, EditText count) {
        // Error handling block begins
        try {
            String nameText = item.getText().toString(); // Get strings from the views
            String countText = count.getText().toString();
            int countTextInt = 0; // Will hold the count converted to an integer.
            String itemExists = getResources().getString(R.string.message_additem_exists);
            String itemAdded = getResources().getString(R.string.message_additem_added);
            String countIncorrect = getResources().getString(R.string.message_additem_countwrong);
            String nameInvalid = getResources().getString(R.string.message_additem_namewrong);

            // Begins validation by checking if the count entered is numeric only and has at most 6 digits
            if (!countText.matches("^[0-9]+$") || countText.length() < 7){ // Does the string contain only Arabic digits and between 1-6 digits?
                countTextInt = Integer.parseInt(countText); // Convert the item count to an integer.
                if (DatabaseManager.getInstance(getApplicationContext()).itemExists(nameText)) { // If this item name is already found, do not add a new entry.
                    msgText.setText(itemExists); // Notify the user
                    throw new InputMismatchException("Item name already exists in the database.");
                } else { // If it passed validation and is not already in the database
                    DatabaseManager.getInstance(getApplicationContext()).addItem(nameText, countTextInt); // Add to database
                    msgText.setText(itemAdded); // Notify user
                }
            }
            else if (nameText == null || nameText.chars().allMatch(Character::isLetterOrDigit) || nameText.length() > 10) { // If name entered is non-alphanumeric, null, or too long
                msgText.setText(nameInvalid);
                throw new SecurityException("Name entered was not 1-10 alphanumeric characters.");
            }
            else { // If a number is not entered correctly, display a message and log error.
                msgText.setText(countIncorrect);
                throw new SecurityException("Count entered was not convertible to an integer or was over the limit.");
            }
        }
        catch (Exception exception) { // catch any kind of exception.
            // Placeholder for future remote logging.
            System.out.println(exception);
        }
    }

    // Prevents the phone's 'back' button from logging out the user from this screen.
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(AddActivity.this, MainActivity.class));
        finish();
    }
}