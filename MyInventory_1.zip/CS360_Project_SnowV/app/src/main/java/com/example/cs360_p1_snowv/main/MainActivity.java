package com.example.cs360_p1_snowv.main;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs360_p1_snowv.add.AddActivity;
import com.example.cs360_p1_snowv.R;
import com.example.cs360_p1_snowv.data.DatabaseManager;
import com.example.cs360_p1_snowv.login.LoginActivity;

import java.util.ArrayList;
import java.util.List;

// Main class for the Main screen/activity (inventory list)
public class MainActivity extends AppCompatActivity {
    // Sets variables and clock listeners for UI elements on creation of this view.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Use this layout.

        // Variables for UI elements
        Button btnLogout = findViewById(R.id.buttonLogOut);
        Button btnAddItem = findViewById(R.id.buttonAddItem);

        // Actions for button clicks
        btnLogout.setOnClickListener(l -> handleLogout());
        btnAddItem.setOnClickListener(l -> openAddActivity());

        // The variable for the Recycler View that displays the inventory
        RecyclerView inventoryList = findViewById(R.id.inventoryList);

        // A local copy of the data for Recycler View to use
        List<itemData> itemList = new ArrayList<>();
        // Cursor that reads & temporarily holds the inventory from the database.
        Cursor cursor = DatabaseManager.getInstance(getApplicationContext()).readItems();
        // Load from database and create a local copy using the itemData class.
        while (cursor.moveToNext()) { // While there is still something in the database cursor
            String name = cursor.getString(0); // get the item's Name
            String count = cursor.getString(1); // get the item's Count
            itemList.add(new itemData(name, count));
        }
        cursor.close(); // Close the temporary Cursor after use.

        // FIXME: The UI appears and code compiles for the Recycler View, but the data is not populating correctly.
        // Set up the Adapter class for the Recycler View which populates it with data.
        inventoryAdapter inventoryAdapter = new inventoryAdapter(itemList, getApplication());
        inventoryList.setAdapter(inventoryAdapter);
        inventoryList.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        // FIXME: Implement the search function. This will interact with the inventoryList Recycler view, so it should change what is in the itemList local data and recreate the view.
    }

    // Method to start the 'Add Item' activity screen.
    private void openAddActivity() {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }

    // Log out the user by returning to login screen.
    // The 'noHistory' line in AndroidManifest.xml prevents using the back button to log in again.
    private void handleLogout() {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
    }
}