package com.example.cs360_p1_snowv;

import org.junit.*;
import static org.junit.Assert.*;

public class LoginTests {
    @Before
    public void setUp() {
        // Set up the environment before each test
    }

    @Test
    // Example test that the two values are equal. Should always pass.
    public void alwaysPass() {
        assertEquals(3 + 3, 6);
    }
}


