package com.vsnow.myinventory.login;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.vsnow.myinventory.R;
import com.vsnow.myinventory.main.MainActivity;
import com.vsnow.myinventory.data.DatabaseManager;


/**
 * The 'login' screen Activity that allows a user to login, create a user, and toggle settings for the My Inventory app.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */
public class LoginActivity extends AppCompatActivity {

    // Private class variables for the changeable UI elements. Prevents unauthorized tampering and enables use in class functions.
    private static final String TAG = "LoginActivity"; // Name of the class used for logging
    private EditText txtUsername;
    private EditText txtPassword;
    private TextView msgText;
    private final String regexAlphaNum = "^[a-zA-Z0-9]*$"; // For validations


    // Set variables and click listeners when this screen (activity) is created.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Use this layout.

        // Variables for UI elements
        txtUsername = findViewById(R.id.entryUsername);
        txtPassword = findViewById(R.id.entryPassword);
        msgText = findViewById(R.id.messageLogin);
        Button btnLogin = (Button)findViewById(R.id.buttonLogIn);
        Button btnNewUser = (Button)findViewById(R.id.buttonNewUser);

        // Actions for button clicks
        btnLogin.setOnClickListener(l -> handleLogin());
        btnNewUser.setOnClickListener(l -> handleNewUser());
    }

    // Clear the text fields when resuming this activity for security purposes.
    @Override
    public void onResume() {
        super.onResume();
        txtPassword.setText("");
        txtUsername.setText("");
        msgText.setText("");
    }

    // Called when 'Login' button is clicked; Validates credentials and runs the main activity.
    private void handleLogin() {
        // Error handling with logging feature.
        try {
            // Convert the fields' current text to a String and get error messages from the xml.
            String username = txtUsername.getText().toString();
            String password = txtPassword.getText().toString();
            String loginError = getResources().getString(R.string.message_login_error);
            String loginWrong = getResources().getString(R.string.message_login_wrong);

            // Validate the input before interacting with the database.
            if (username == null || password == null){
                msgText.setText(loginError); // Show message to the user.
                throw new IllegalArgumentException("Username and password field cannot be empty.");
            }
            else if (username.length() > 10 || password.length() > 25) { // Check username & password length to prevent memory overuse or overflow.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password entered was longer than the maximum length.");
            }
            else if ( !username.matches(regexAlphaNum) || !password.matches(regexAlphaNum)) { // Check that something was entered in the fields and is alphanumeric.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password must contain only alphanumeric characters and not be empty.");
            }
            else {
                // If username and password match is found in database, log in the user and go to main activity. If not, display error message.
                if (DatabaseManager.getInstance(getApplicationContext()).authenticate(username, password)) {
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                } else {
                    msgText.setText(loginWrong); // Show message to the user.
                    throw new SecurityException("Invalid credentials were entered.");
                }
            }
        }
        catch (Exception exception){ // Code to run in case of any exception.
            Log.e(TAG, "An error occurred in handleLogin while attempting to log in the user.", exception);
        }
    }

    // Called when 'New User' button is clicked; Adds a new user with input as credentials given.
    private void handleNewUser() {
        try {
            // Convert the fields' current text to a String.
            String username = txtUsername.getText().toString();
            String password = txtPassword.getText().toString();
            String loginError = getResources().getString(R.string.message_login_error);
            String userExists = getResources().getString(R.string.message_newuser_exists);
            String userAdded = getResources().getString(R.string.message_newuser_added);

            // Validate the input before interacting with the database.
            if (username == null || password == null){
                msgText.setText(loginError); // Show message to the user.
                throw new IllegalArgumentException("Username and password cannot be null.");
            }
            else if (username.length() < 4 || username.length() > 10 || password.length() < 8 || password.length() > 25) { // Credential requirements for security and to prevent overflow.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password entered was longer or shorter than allowed length.");
            }
            else if ( !username.matches(regexAlphaNum) || !password.matches(regexAlphaNum)) { // Check that something was entered in the fields and is alphanumeric.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password must contain only alphanumeric characters and not be empty.");
            }
            else {
                // If the username already exists, display an error message.
                if (DatabaseManager.getInstance(getApplicationContext()).userExists(username)) {
                    msgText.setText(userExists); // Show message to the user.
                } else { // If not found in the database, add the user.
                    DatabaseManager.getInstance(getApplicationContext()).addUser(username, password); // Add to the database.
                    msgText.setText(userAdded); // Show message to the user.
                }
            }
        }
        catch (Exception exception) {
            Log.e(TAG, "An error occurred in handleNewUser while attempting to add a new user.", exception);
        }
    }
}
