/**
 * This class handles communication with the SQLite database for the My Inventory app.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */

package com.vsnow.myinventory.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.nio.BufferOverflowException;

public class DatabaseManager extends SQLiteOpenHelper {
    // TODO: Use the regex String pattern from LoginActivity and initialize it only once in the private fields for validations.
    private static final String TAG = "DatabaseManager"; // Name of the class used for logging
    private static DatabaseManager instance;
    private static final String DATABASE_NAME = "data.db";
    private static final int VERSION = 3;

    // Singleton pattern context getter ensures that multiple DatabaseManager instances are not created.
    public static DatabaseManager getInstance(Context context){
        if (instance == null){
            instance = new DatabaseManager(context);
            Log.v(TAG, "No instance of DatabaseManager exists. Creating...");
        }
        else {
            Log.v(TAG, "An instance of DatabaseManager exists. Fetching...");
        }
        return instance;
    }

    // Constructor using current application SQLite context.
    private DatabaseManager(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        try {
            db.execSQL("CREATE TABLE " + UserTable.TABLE + " (" +
                    UserTable.COL_USERNAME + " text primary key, " +
                    UserTable.COL_PASSWORD + " text)");

            db.execSQL("CREATE TABLE " + ItemTable.TABLE + " (" +
                    ItemTable.COL_ITEMNAME + " text primary key, " +
                    ItemTable.COL_NUMINSTOCK + " integer)");
        }
        catch (Exception exception) {
            Log.e(TAG, "Something went wrong while creating the database tables.", exception);
        }
    }

    // Mandatory to include in this class; Logic for what to do on upgrade, if anything.
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.v(TAG, "SQLiteDatabase has been upgraded.");
    }

    /**
     * Method to verify login credentials.
     * @param username The name for the User to check for a match. Unique primary key.
     * @param password The password to verify for the User.
     * @return A boolean stating whether a match for the credentials were found.
     */
    public boolean authenticate(String username, String password){

        boolean isAuthenticated = false;

        try { // Attempt to read the database and find a matching USERNAME primary key.
            SQLiteDatabase db = getReadableDatabase();
            String sql = "select * from " + UserTable.TABLE +
                    " WHERE " + UserTable.COL_USERNAME + " = ? AND " +
                    UserTable.COL_PASSWORD + " = ? ";
            Cursor cursor = db.rawQuery(sql, new String[]{username, password});

            if (cursor.moveToFirst()) { // If a matching username and password is found
                isAuthenticated = true;
            } else { // Ensure that the authentication fails
                isAuthenticated = false;
            }
        }
        catch (Exception exception) { // If any of the above process fails
            isAuthenticated = false; // For safety, ensure the authentication is not approved.
            Log.e(TAG, "An error caused the user retrieval and validation process to fail.", exception);
        }

        return isAuthenticated;
    }

    /**
     * Method to verify credentials when attempting to create a new user.
     * @param username The name for the User to check for a match. Unique primary key.
     * @return A boolean stating whether the username already exists in the database.
     */
    public boolean userExists(String username){

        boolean exists = false; // initialize the return variable to a default.

        try {
            SQLiteDatabase db = getReadableDatabase();
            String sql = "select * from " + UserTable.TABLE +
                    " WHERE " + UserTable.COL_USERNAME + " = ? ";
            Cursor cursor = db.rawQuery(sql, new String[]{username});

            if (cursor.moveToFirst()) { // If a matching USERNAME is found
                exists = true;
            } else { // Else ensure the function returns false
                exists = false;
            }
        }
        catch (Exception exception) {
            Log.e(TAG, "Something went wrong while attempting to find a matching username in userExists method.", exception);
        }

        return exists;
    }

    /**
     * CRUD Method to Create a new User in the database. Returns a new id key, or '0' in case of failure.
     * @param name The name field for the User. Unique primary key.
     * @param pass The password field for the user.
     */
    public long addUser(String name, String pass) {
        SQLiteDatabase db = getWritableDatabase();
        long userId = 0; // Initialize the return value with a default.

        try {
            // Validate the input "server-side" before interacting with the database.
            ContentValues values = new ContentValues();

            if ( name == null || pass == null ) { // Check if username & password are null first.
                throw new SecurityException("Username or password was found to be null.");
            }
            else if (name.length() > 10 || pass.length() > 25) { // Check username & password length to prevent memory overuse or overflow.
                throw new SecurityException("Username or password entered was longer than the maximum length.");
            }
            else if ( !name.matches("/^[A-Za-z0-9]+$/") || !pass.matches("/^[A-Za-z0-9]+$/")) { // Check that the name and password are alphanumeric.
                throw new SecurityException("Username or password must contain only alphanumeric characters.");
            }
            else { // Input is safe, enter into database.
                values.put(UserTable.COL_USERNAME, name);
                values.put(UserTable.COL_PASSWORD, pass);
                userId = db.insert(UserTable.TABLE, null, values);
            }
        }
        catch (Exception exception) {
            Log.e(TAG, "An error occurred in the addUser method.", exception);
        }
        return userId; // If returning '0' there was an error.
    }

    /**
     * CRUD Method to Read a User from the database.
     * @param itemName The name field for the Username to look up. Unique primary key.
     * @return A boolean indicating whether or not the item name was found.
     */
    public boolean itemExists(String itemName){

        boolean exists = false; // Initialize the return variable to a default.

        try { // Attempt to search the database for the given Item in the database.
            SQLiteDatabase db = getReadableDatabase();
            String sql = "select * from " + ItemTable.TABLE +
                    " WHERE " + ItemTable.COL_ITEMNAME + " = ? ";
            Cursor cursor = db.rawQuery(sql, new String[]{itemName});

            if (cursor.moveToFirst()) { // If a matching ITEMNAME primary key is found
                exists = true;
            } else { // Else ensure the function returns false
                exists = false;
            }
        }
        catch (Exception exception){
            Log.e(TAG, "An error occurred in itemExists while trying to find an item in the database.", exception);
        }

        return exists;
    }

    /**
     * CRUD Method to Create an Item in the database. Returns a long ID for the created entry, 0 if failed.
     * @param name The name field for the User to look up. Unique primary key.
     * @param count The number in stock (NUMINSTOCK) field for the item.
     * @return A long item ID of the created Item, or 0 if creation failed.
     */
    public long addItem(String name, int count) {

        long itemId = 0; // Initialize return variable to a default.

        try {
            if ( name == null ) { // Check if the name is null, integers can't be null so no need to check here.
                throw new IllegalArgumentException("Name was found to be null.");
            }
            else if (count < 0 || count > 999999) { // If the count is not within the limits of the application
                throw new Exception("The count was under 0 or longer than 6 digits.");
            }
            else if (!name.matches("/^[A-Za-z0-9]+$/")) {
                throw new IllegalArgumentException("Item name was not alphanumeric.");
            }
            else { // Validated, attempt to add to the database.
                SQLiteDatabase db = getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(ItemTable.COL_ITEMNAME, name);
                values.put(ItemTable.COL_NUMINSTOCK, count);
                itemId = db.insert(ItemTable.TABLE, null, values);
            }
        }
        catch (Exception exception){
            Log.e(TAG, "An error occurred in addItem while trying to create a new entry in the database.", exception);
        }

        return itemId;
    }

    /**
     * Method to read from the database and return all items as an iterable object.
     * @return an iterable Cursor of the ItemTable.
     */
    public Cursor readItems(){

        SQLiteDatabase db = getWritableDatabase();
        String sql = "select * from " + ItemTable.TABLE;

        Cursor cursor = db.rawQuery(sql, new String[]{});
        return cursor;

    }

    /**
     * Method to update an item's count in the database.
     * @param name the item's unique name.
     * @param count the item' current count.
     * @param direction 0 for increasing, 1 for decreasing.
     * @return a Boolean indicating if any rows have been updated in the table.
     */
    public boolean updateItem(String name, String count, int direction) {
        SQLiteDatabase db = getWritableDatabase();
        int countInt = Integer.parseInt(count);
        int rowsUpdated = 0;

        try {
            if (direction == 0) { // If Up was clicked
                countInt += 1;
                if (countInt > 999999) { // Do not increase the count to a number greater than 6 digits.
                    throw new Exception("Item count cannot be greater than six digits.");
                }
                else {
                    Log.v(TAG, "Increased an item's count by 1.");
                }
            } else if (direction == 1) { // If Down was clicked
                countInt -= 1;
                if (countInt <= 0) { // Do not decrease count to less than 0.
                    throw new Exception("Item count cannot be less than zero.");
                } else {
                    Log.v(TAG, "Decreased an item's count by 1.");
                }
            } else { // If the provided direction argument was neither 0 nor 1 (increase or decrease)
                throw new IllegalArgumentException("Updating item count failed. Invalid argument for direction parameter.");
            }
            // If direction was provided, attempt to update the item.
            ContentValues values = new ContentValues();
            values.put(ItemTable.COL_NUMINSTOCK, Integer.toString(countInt));
            rowsUpdated = db.update(ItemTable.TABLE, values, "item_name = ?",
                    new String[] { name });
        }
        catch (Exception exception) {
            Log.e(TAG, "Something went wrong while updating the item count.", exception);
        }
        return rowsUpdated > 0;
    }

     /**
     * Method to delete an inventory item from the database.
     * @param name the unique name of an item.
     * @return A Boolean indicating if any rows were deleted.
     */
    public boolean deleteItem(String name) {

        int rowsDeleted = 0; // initialize the return variable with a default.

        try { // Attempt to find the item in the database and delete it.
            SQLiteDatabase db = getWritableDatabase();
            rowsDeleted = db.delete(ItemTable.TABLE, ItemTable.COL_ITEMNAME + " = ?",
                    new String[]{name});
        }
        catch (Exception exception){ // If errors occur during the process
            Log.e(TAG, "Something went wrong while trying to delete an item.", exception);
        }

        return rowsDeleted > 0;
    }

    // Database Table structures
    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";

    }

    private static final class ItemTable{

        private static final String TABLE = "items";
        private static final String COL_ITEMNAME = "item_name";
        private static final String COL_NUMINSTOCK = "stock";

    }

}
