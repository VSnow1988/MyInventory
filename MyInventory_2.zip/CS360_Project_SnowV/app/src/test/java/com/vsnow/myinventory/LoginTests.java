/**
 * The automated tests for functions in the Login Activity.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */
package com.vsnow.myinventory;

import org.junit.*;
import static org.junit.Assert.*;
import com.vsnow.myinventory.login.LoginActivity;

public class LoginTests {
    @Before
    public void setUp() {
        // Set up the environment before each test
    }

    @Test
    // Example test that the two values are equal. Should always pass.
    public void alwaysPass() {
        assertEquals(3 + 3, 6);
    }

}

// TODO: Junit tests for each function.


