package com.example.cs360_p1_snowv.login;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360_p1_snowv.R;
import com.example.cs360_p1_snowv.main.MainActivity;
import com.example.cs360_p1_snowv.data.DatabaseManager;



public class LoginActivity extends AppCompatActivity {

    private EditText txtUsername;
    private EditText txtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtUsername = findViewById(R.id.nameEntry);
        txtPassword = findViewById(R.id.passwordEntry);

        Button btnLogin = (Button)findViewById(R.id.buttonLogIn);
        Button btnNewUser = (Button)findViewById(R.id.buttonNewUser);

        btnLogin.setOnClickListener(l -> handleLogin());
        btnNewUser.setOnClickListener(l -> handleNewUser());

    }

    @Override
    // Clear the text fields when resuming this activity.
    public void onResume() {
        super.onResume();
        txtPassword.setText("password");
        txtUsername.setText("username");
    }

    // Called when 'Login' is pressed; Validates credentials and runs the main activity
    private void handleLogin() {
        String username = txtUsername.getText().toString();
        String password = txtPassword.getText().toString();

        if (DatabaseManager.getInstance(getApplicationContext()).authenticate(username, password)){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(this,"Invalid Credentials. Please create a new user.",Toast.LENGTH_LONG).show();
        }
    }

    // Called when 'New User' button is clicked; Adds a new user with input as credentials
    private void handleNewUser() {
        String username = txtUsername.getText().toString();
        String password = txtPassword.getText().toString();

        // If the username already exists, send an error. Else, add a new user to the database.
        if (DatabaseManager.getInstance(getApplicationContext()).userExists(username)){
            Toast.makeText(this,"Username already exists.",Toast.LENGTH_LONG).show();
        }
        else { // If not found in the database, add a user.
            DatabaseManager.getInstance(getApplicationContext()).addUser(username, password);
            Toast.makeText(this,"New user added to database.",Toast.LENGTH_LONG).show();
        }
    }

}
