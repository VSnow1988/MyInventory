package com.example.cs360_p1_snowv.add;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.cs360_p1_snowv.R;
import com.example.cs360_p1_snowv.data.DatabaseManager;
import com.example.cs360_p1_snowv.main.MainActivity;

public class AddActivity extends AppCompatActivity {

    private TextView msgText;
    private EditText itemName;
    private EditText itemCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // Variables for UI elements
        Button btnAddConfirm = findViewById(R.id.buttonAddConfirm);
        Button btnReturnHome = findViewById(R.id.buttonReturnMain);
        msgText = findViewById(R.id.addMessage);
        itemName = findViewById(R.id.addItemNameInput);
        itemCount = findViewById(R.id.addNumberInput);

        // Actions to call for button clicks
        btnAddConfirm.setOnClickListener(l -> handleAddConfirm(itemName, itemCount));
        btnReturnHome.setOnClickListener(l -> handleReturnHome());
    }

    // Go back to the Main Activity
    private void handleReturnHome() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    // Add the item to the database and display confirmation.
    private void handleAddConfirm(EditText item, EditText count) {
        String nameText = item.getText().toString(); // Get strings from the views
        String countText = count.getText().toString();
        int countTextInt = Integer.parseInt(countText); // Convert the item count to an integer.

        // If this item name is already found, do not add a new entry.
        if (DatabaseManager.getInstance(getApplicationContext()).itemExists(nameText)) {
            msgText.setText(nameText + " already exists in inventory list.");
        }
        else {
            DatabaseManager.getInstance(getApplicationContext()).addItem(nameText, countTextInt);
            msgText.setText(nameText + " added to the inventory list.");
        }
    }

    // Fixes issue where back button will log out from here.
    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        startActivity(new Intent(AddActivity.this, MainActivity.class));
        finish();
    }
}