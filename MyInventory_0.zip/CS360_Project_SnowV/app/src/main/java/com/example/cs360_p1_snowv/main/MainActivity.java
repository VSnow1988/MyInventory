package com.example.cs360_p1_snowv.main;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360_p1_snowv.add.AddActivity;
import com.example.cs360_p1_snowv.R;
import com.example.cs360_p1_snowv.data.DatabaseManager;
import com.example.cs360_p1_snowv.login.LoginActivity;
import com.google.android.material.resources.TextAppearance;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnLogout = findViewById(R.id.buttonLogOut);
        Button btnAddItem = findViewById(R.id.buttonAddItem);

        btnLogout.setOnClickListener(l -> handleLogout());
        btnAddItem.setOnClickListener(l -> openAddActivity());
        Cursor itemList = DatabaseManager.getInstance(getApplicationContext()).readItems();

        // Load from database and create a row to display each item in the inventory.
        while (itemList.moveToNext()) {
                String name = itemList.getString(0);
                String count = itemList.getString(1);
                generateTableRow(name, count);
            }
        itemList.close();
    }

    // Start the 'Add Item' activity screen.
    private void openAddActivity() {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }

    // Log out the user by returning to login screen.
    // The 'noHistory' line in AndroidManifest prevents using the back button to log in again.
    private void handleLogout() {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
    }

    // Makes a TableRow view to add to the table.
    private void generateTableRow(String name, String count){

        TableLayout itemTable = findViewById(R.id.itemTable);

        // FIXME: This row & its contents are not showing up the proper height. Images are not visible on buttons.
        TableRow r = new TableRow(getApplicationContext());
        r.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, 50));

        TextView t = new TextView(this);
        t.setText(name + " - " + count);
        t.setLayoutParams(new TableRow.LayoutParams(201, TableRow.LayoutParams.MATCH_PARENT));
        // t.setTextAppearance(); // FIXME: Set this to 'Large' built-in style, or increase text size & bold.

        ImageButton u = new ImageButton(getApplicationContext());
        u.setLayoutParams(new TableRow.LayoutParams(70, TableRow.LayoutParams.MATCH_PARENT));
        u.setImageDrawable(Drawable.createFromPath("@android:drawable/arrow_up_float"));

        ImageButton d = new ImageButton(getApplicationContext());
        d.setLayoutParams(new TableRow.LayoutParams(70, TableRow.LayoutParams.MATCH_PARENT));
        d.setImageDrawable(Drawable.createFromPath("@android:drawable/arrow_down_float"));

        ImageButton x = new ImageButton(getApplicationContext());
        x.setLayoutParams(new TableRow.LayoutParams(70, TableRow.LayoutParams.MATCH_PARENT));
        x.setImageDrawable(Drawable.createFromPath("@android:drawable/ic_delete"));


        // Add the buttons to the row.
        r.addView(t);
        r.addView(u);
        r.addView(d);
        r.addView(x);

        // Set click action for delete button.
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Deletes the item from the database.
                DatabaseManager.getInstance(getApplicationContext()).deleteItem(name);
                // Removes parent TableRow from the screen.
                ViewGroup parent = (ViewGroup) x.getParent();
                parent.removeAllViews();
                if(parent.getParent() != null){
                    ((ViewGroup) parent.getParent()).removeView(parent);
                }
            }
        });

        // Set click action for up button. FIXME: Reload row when clicked
        u.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseManager.getInstance(getApplicationContext()).updateItem(name, count, 0);
                }
        });

        // Set click action for down button. FIXME: Reload row when clicked
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseManager.getInstance(getApplicationContext()).updateItem(name, count, 1);
            }
        });

        // Add the completed row to the table.
        itemTable.addView(r);
    }

}