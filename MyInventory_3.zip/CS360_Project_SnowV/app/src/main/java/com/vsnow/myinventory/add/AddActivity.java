package com.vsnow.myinventory.add;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.vsnow.myinventory.R;
import com.vsnow.myinventory.data.DatabaseManager;
import com.vsnow.myinventory.main.MainActivity;

import java.util.InputMismatchException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The 'add' screen Activity that allows a user to add items to the list in the My Inventory app.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */
public class AddActivity extends AppCompatActivity {

    // Private variable declarations for changeable UI elements.
    private static final String TAG = "AddActivity"; // Name of the class used for logging
    private TextView msgText;
    private EditText itemName;
    private EditText itemCount;

    // Regex patterns, efficiently compiled only once to use in validation.
    private Pattern alphaNum = Pattern.compile("/^[A-Za-z0-9]+$/");
    private Pattern numeric = Pattern.compile("^[0-9]+$");


    // Assigns variables for UI elements and click listeners for buttons when this view is created.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add); // Use this layout.
        getSupportActionBar().hide(); // Hide the extra title bar.

        // Variables for UI elements
        Button btnAddConfirm = findViewById(R.id.buttonConfirm);
        Button btnReturnHome = findViewById(R.id.buttonReturn);
        msgText = findViewById(R.id.messageAdd);
        itemName = findViewById(R.id.entryItemName);
        itemCount = findViewById(R.id.entryItemCount);

        // Actions for button clicks
        btnAddConfirm.setOnClickListener(l -> handleAddConfirm(itemName, itemCount));
        btnReturnHome.setOnClickListener(l -> handleReturnHome());
    }

    // Method to go back to the Main activity
    private void handleReturnHome() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    /**
     * Handles the 'add item' function. Validates the input before adding to the database. Displays a confirmation message to the user.
     * @param item the unique name of the Item to add to the database, from the input field.
     * @param count the count of items to start with, from the user input field.
     */
    // TODO 3: Update handleAddConfirm function for Firebase.
    private void handleAddConfirm(EditText item, EditText count) {
        // Error handling block begins
        try {
            String nameText = item.getText().toString(); // Get strings from the views
            String countText = count.getText().toString();
            int countTextInt = 0; // Will hold the count converted to an integer.
            String itemExists = getResources().getString(R.string.message_additem_exists);
            String itemAdded = getResources().getString(R.string.message_additem_added);
            String countIncorrect = getResources().getString(R.string.message_additem_countwrong);
            String nameInvalid = getResources().getString(R.string.message_additem_namewrong);

            // Regex matchers
            Matcher countMatch = numeric.matcher(countText);
            Matcher nameMatch = alphaNum.matcher(nameText);

            // Begins validation by checking if the count entered is numeric only and has at most 6 digits
            if ( !countMatch.matches() || countText.length() < 7){ // Does the string contain only Arabic digits and between 1-6 digits?
                countTextInt = Integer.parseInt(countText); // Convert the item count to an integer.
                if (DatabaseManager.getInstance(getApplicationContext()).itemExists(nameText)) { // If this item name is already found, do not add a new entry.
                    msgText.setText(itemExists); // Notify the user
                    throw new InputMismatchException("Item name already exists in the database.");
                } else { // If it passed validation and is not already in the database
                    DatabaseManager.getInstance(getApplicationContext()).addItem(nameText, countTextInt); // Add to database
                    msgText.setText(itemAdded); // Notify user
                }
            }
            else if (nameText == null || !nameMatch.matches() || nameText.length() > 10) { // If name entered is non-alphanumeric, null, or too long
                msgText.setText(nameInvalid);
                throw new SecurityException("Name entered was not 1-10 alphanumeric characters.");
                // FIXME: This allowed an 11-character String to enter.
            }
            else { // If a number is not entered correctly, display a message and log error.
                msgText.setText(countIncorrect);
                throw new SecurityException("Count entered was not convertible to an integer or was over the limit.");
            }
        }
        catch (Exception exception) { // catch any kind of exception.
            Log.e(TAG, "An exception occurred while trying to add a new item: ", exception);
        }
    }

    // Prevents the phone's 'back' button from logging out the user from this screen, which would be a great inconvenience to the user.
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(AddActivity.this, MainActivity.class));
        finish();
    }
}