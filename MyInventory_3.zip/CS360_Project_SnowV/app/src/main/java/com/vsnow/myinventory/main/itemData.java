package com.vsnow.myinventory.main;

/**
 * This class structures the local copy of data for items in the My Inventory app taken from the database, for use in the Recycler View.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */
public class itemData {

    private static final String TAG = "itemData"; // Name of the class used for logging
    String name;
    String count;

/**
 * Class constructor for object holding data from the ItemTable as a local copy.
 * @param   name    the 'Name' field of the entry in the ItemTable as a String
 * @param   count    the 'Count' field of the entry in the ItemTable as a String
 */
    itemData(String name, String count){
        this.name = name;
        this.count = count;
    }
}
