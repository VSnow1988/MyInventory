package com.vsnow.myinventory.main;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.vsnow.myinventory.add.AddActivity;
import com.vsnow.myinventory.R;
import com.vsnow.myinventory.data.DatabaseManager;
import com.vsnow.myinventory.login.LoginActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * The 'main' screen Activity that displays the inventory list, add, search, and logout actions for the My Inventory app.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */
public class MainActivity extends AppCompatActivity {

    // Sets variables and clock listeners for UI elements on creation of this view.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Use this layout.
        getSupportActionBar().hide(); // Hide the extra title bar.

        // Variables for UI elements
        Button btnLogout = findViewById(R.id.buttonLogOut);
        Button btnAddItem = findViewById(R.id.buttonAddItem);
        Button btnShowZero = findViewById(R.id.buttonShowZero);

        // Actions for button clicks
        btnLogout.setOnClickListener(l -> handleLogout());
        btnAddItem.setOnClickListener(l -> openAddActivity());

        // The variable for the Recycler View that displays the inventory
        RecyclerView inventoryList = findViewById(R.id.inventoryList);

        // TODO 2: Update this to create an itemList from Firebase data instead of the local SQLite and create new CRUD methods.
        // A local copy of the data for Recycler View to use
        List<itemData> itemList = new ArrayList<>();
        // Cursor that reads & temporarily holds the inventory from the database.
        Cursor cursor = DatabaseManager.getInstance(getApplicationContext()).readItems();
        // Load from database and create a local copy using the itemData class.
        while (cursor.moveToNext()) { // While there is still something in the database cursor
            String name = cursor.getString(0); // get the item's Name
            String count = cursor.getString(1); // get the item's Count
            itemList.add(new itemData(name, count));
        }
        cursor.close(); // Close the temporary Cursor after use.

        // Set up the Adapter class for the Recycler View which populates it with data.
        inventoryAdapter invAdapter = new inventoryAdapter(itemList, getApplication());
        inventoryList.setAdapter(invAdapter);
        inventoryList.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        btnShowZero.setOnClickListener(l -> invAdapter.toggleZero()); // Set toggle function for the 0 Stock button

        // TODO 4: Implement the search function. This will interact with the inventoryList Recycler view, so it should change what is in the itemList local data and recreate the view.
    }

    // Method to start the 'Add Item' activity screen.
    private void openAddActivity() {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }

    // Log out the user by returning to login screen.
    // The 'noHistory' line in AndroidManifest.xml prevents using the back button to log in again.
    private void handleLogout() {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
    }

}