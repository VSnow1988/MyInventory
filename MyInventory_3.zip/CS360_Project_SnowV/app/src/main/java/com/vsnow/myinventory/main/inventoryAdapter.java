package com.vsnow.myinventory.main;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.vsnow.myinventory.R;
import com.vsnow.myinventory.data.DatabaseManager;

import java.util.Collections;
import java.util.List;

/**
 * This class populates the list on the MainActivity screen with data from the SQLite database, displaying inventory to the user and its CRUD options.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */
public class inventoryAdapter extends RecyclerView.Adapter<inventoryViewHolder> {
    private static final String TAG = "inventoryAdapter"; // Name of the class used for logging
    private List<itemData> localDataSet = Collections.emptyList(); // Will hold a local copy of the data to pass in
    private Context context;
    private Boolean showZero = false;

    // Initializer for the Adapter with the list of itemData created in the Main Activity
    public inventoryAdapter(List<itemData> list, Context context) {
        localDataSet = list;
    }
    // TODO: Make this list alphabetized, using item name as the sorting value in the itemData class. 

    // The ViewHolder holds the views that we wish to 'recycle' with different data in them (in this case, our list rows)
    // Create new views (invoked by the layout manager)
    @NonNull
    @Override
    public inventoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        context = parent.getContext(); // Use the application context
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the layout using the inventory_item.xml
        View inventoryView = inflater.inflate(R.layout.inventory_item, parent, false);

        return new inventoryViewHolder(inventoryView);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(final inventoryViewHolder viewHolder, final int position) {
        // Get element from your dataset at this position and replace the contents of the view with that element
        String itemCount = localDataSet.get(position).count;
        String itemName = localDataSet.get(position).name;
        viewHolder.textItemName.setText(itemName);
        viewHolder.textItemCount.setText(itemCount);

        if (showZero) { // If the '0 Stock' toggle is on
            int numCount = Integer.parseInt(itemCount);
            if (numCount > 0) { // If the item count is greater than zero, don't add it.
                // Do nothing, go to next position
            }
            else { // If the item count is zero (or less, but these have already been validated elsewhere)
                // Add it to the list
                // Sets the decrease count button function for this item.
                viewHolder.buttonItemDecrease.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DatabaseManager.getInstance(context.getApplicationContext()).updateItem(itemName, itemCount, 1);
                        notifyItemChanged(viewHolder.getAdapterPosition());
                    }
                });
                // Sets the increase count button function for this item.
                viewHolder.buttonItemIncrease.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DatabaseManager.getInstance(context.getApplicationContext()).updateItem(itemName, itemCount, 0);
                        notifyItemChanged(viewHolder.getAdapterPosition());
                    }
                });
                // Sets the delete button function for this item.
                viewHolder.buttonItemDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // FIXME: Have user confirm deletion first.
                        DatabaseManager.getInstance(context.getApplicationContext()).deleteItem(itemName);
                        notifyItemRemoved(viewHolder.getAdapterPosition());
                    }
                });
            }
        }
        else { // If showZero is false, show the entire inventory list to the view.
            // Sets the decrease count button function for this item.
            viewHolder.buttonItemDecrease.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DatabaseManager.getInstance(context.getApplicationContext()).updateItem(itemName, itemCount, 1);
                    notifyItemChanged(viewHolder.getAdapterPosition());
                }
            });
            // Sets the increase count button function for this item.
            viewHolder.buttonItemIncrease.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DatabaseManager.getInstance(context.getApplicationContext()).updateItem(itemName, itemCount, 0);
                    notifyItemChanged(viewHolder.getAdapterPosition());
                }
            });
            // Sets the delete button function for this item.
            viewHolder.buttonItemDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // FIXME: Have user confirm deletion first.
                    DatabaseManager.getInstance(context.getApplicationContext()).deleteItem(itemName);
                    notifyItemRemoved(viewHolder.getAdapterPosition());
                }
            });
        }
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return localDataSet.size();
    }

    // Method for the 'show zero count items only' feature.
    public void toggleZero() {
        // FIXME: Debug this function. It isn't working.
        // Toggle the showZero Boolean indicator.
        if (!showZero) {
            showZero = true;
        }
        else {
            showZero = false;
        }
        notifyDataSetChanged();
    }

}

