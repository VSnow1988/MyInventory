package com.vsnow.myinventory.login;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.vsnow.myinventory.R;
import com.vsnow.myinventory.main.MainActivity;

import java.util.HashMap;
import java.util.Map;


/**
 * The 'login' screen Activity that allows a user to login, create a user, and toggle settings for the My Inventory app.
 * @author Vincent Snow vincent.snow@snhu.edu
 * @version 2.1.0
 */
public class LoginActivity extends AppCompatActivity {

    // Private class variables for the changeable UI elements. Prevents unauthorized tampering and enables use in class functions.
    private static final String TAG = "LoginActivity"; // Name of the class used for logging
    private EditText txtUsername;
    private EditText txtPassword;
    private TextView msgText;

    /**
     * Connect to the Firestore database for use in this class. The google-services JSON file in the root directory is needed to connect.
     * Firestore is a NoSQL non-relational remote database service (part of Google Firebase suite) with many built-in security features, scalability, useful libraries and strong support.
     * If experiencing trouble running & testing, ensure that you are using a Google Play-enabled emulator.
     */
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    // Set variables and click listeners when this screen (activity) is created.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Use this layout.
        getSupportActionBar().hide(); // Hide the extra title bar.

        // Variables for UI elements
        txtUsername = findViewById(R.id.entryUsername);
        txtPassword = findViewById(R.id.entryPassword);
        msgText = findViewById(R.id.messageLogin);
        Button btnLogin = findViewById(R.id.buttonLogIn);
        Button btnNewUser = findViewById(R.id.buttonNewUser);

        // Actions for button clicks
        btnLogin.setOnClickListener(l -> handleLogin());
        btnNewUser.setOnClickListener(l -> handleNewUser());

    }

    // Clear the text fields when resuming this activity for security purposes.
    @Override
    public void onResume() {
        super.onResume();
        txtPassword.setText("");
        txtUsername.setText("");
        msgText.setText("");
    }

    /**
     * Method to determine Alphanumeric String. Efficient method for Java 8+. Java regex classes have some bugs in current versions of Android/Kotlin/Compose.
     * @param str A String to check for alphanumeric-only character values.
     * @return A boolean that indicates whether or not the string is alphanumeric.
     */
    boolean isAlphaNumeric(String str) {
        return str != null && str.chars().allMatch(Character::isLetterOrDigit);
    }

    /**
     * Log in feature handler. Call when 'Login' button is clicked. Validates credentials and runs the main activity.
     */
    private void handleLogin() {

        String unknownError = getResources().getString(R.string.message_unknown_error);

        try {
            // Convert the fields' current text to a String and get error messages from the xml.
            String username = txtUsername.getText().toString();
            String password = txtPassword.getText().toString();
            String loginError = getResources().getString(R.string.message_login_error);
            String loginWrong = getResources().getString(R.string.message_login_wrong);
            String dbError = getResources().getString(R.string.message_db_error);

            // Validate the input before interacting with the database.
            if (username.length() > 15 || password.length() > 25) { // Check username & password length to prevent memory overuse or overflow.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password entered was longer than the maximum length.");
            } else if ( !isAlphaNumeric(username) || !isAlphaNumeric(password) ) { // Check that something was entered in the fields and is alphanumeric. Prevents code injection.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password must contain only alphanumeric characters and not be empty.");
            } else {
                // If username and password match is found in database, log in the user and go to main activity. If not, display error message.
                Intent intent = new Intent(this, MainActivity.class); // Compiler will get confused if this is declared any deeper

                // Try to find a matching entry for username and password. Fetching username is O(1), password match is O(n) where n is the shortest of the comparing strings.
                // This method of validation avoids unnecessary reads or storage and minimizes possible exposure of private data.
                DocumentReference docRef = db.collection("users").document(username); // Get the matching user document.
                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) { // If communication with database is successful
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) { // If the document retrieved is not null and the user was found
                                if (document.get("password").equals(password)) { // If the password matches
                                    // TODO 1: Consider security. Can this be circumvented to start the Main activity? Do we need an indicator or token as an extra verification layer?
                                    startActivity(intent);
                                }
                                else { // If the password does not match
                                    msgText.setText(loginWrong);
                                    Log.e(TAG, "Password was incorrect.");
                                }
                            } else { // The username was not found.
                                msgText.setText(loginWrong);
                                Log.d(TAG, "No such document exists for user entered.");
                            }
                        } else {
                            Log.d(TAG, dbError, task.getException());
                        }
                    }
                });
            }
        } catch (Exception exception) { // Code to run in case of any exception
            Log.e(TAG, "An error occurred in handleLogin while attempting to log in the user.", exception);
        }
    }

    /**
     * 'Add new user' function handler. Call when 'New User' is clicked. Validates that user does not exist and is safe input before adding to database.
     */
    private void handleNewUser() {

        String unknownError = getResources().getString(R.string.message_unknown_error);

        try {
            // Convert the fields' current text to a String.
            String username = txtUsername.getText().toString();
            String password = txtPassword.getText().toString();
            String loginError = getResources().getString(R.string.message_login_error);
            String dbError = getResources().getString(R.string.message_db_error);
            String userExists = getResources().getString(R.string.message_newuser_exists);
            String userAdded = getResources().getString(R.string.message_newuser_added);

            // Validate the input before interacting with the database.
            if (username.length() < 4 || username.length() > 15 || password.length() < 8 || password.length() > 25) { // Credential requirements for security and to prevent overflow or DoS.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password entered was longer or shorter than allowed length.");
            }
            else if ( !isAlphaNumeric(username) || !isAlphaNumeric(password) ) { // Check that something was entered in the fields and is alphanumeric. Prevents code injections.
                msgText.setText(loginError); // Show message to the user.
                throw new SecurityException("Username or password must contain only alphanumeric characters and not be empty.");
            }
            else {
                // If the username already exists, display an error message.
                DocumentReference docRef = db.collection("users").document(username); // Query a matching user document.
                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) { // If communication with database is successful
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) { // If the document retrieved is not null and the user was found
                                msgText.setText(userExists); // Show message to the user.
                            } else { // If not found in the database, add the user.
                                // Create object for Firebase
                                Map<String, Object> users = new HashMap<>();
                                users.put("password", password);

                                // Add a new document with a generated ID to Firebase, with error logging.
                                db.collection("users").document(username)
                                        .set(users)
                                        .addOnSuccessListener(aVoid -> {
                                            // Show a confirmation message on-screen to the user as well as in Logcat
                                            msgText.setText(userAdded);
                                            Log.d(TAG, "DocumentSnapshot successfully written! " + "Username: " + username);
                                        })
                                        .addOnFailureListener(e -> {
                                            // Show a message to the user about the error as well as in Logcat
                                            msgText.setText(dbError);
                                            Log.w(TAG, "Error adding document", e);
                                        });
                            }
                        }
                    }
                });
            }
        }
        catch (Exception exception) {
            Log.e(TAG, "An error occurred in handleNewUser while attempting to add a new user.", exception);
        }
    }
}